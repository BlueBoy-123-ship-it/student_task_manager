import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/firestore_service.dart';
import '../services/pdf_storage_service.dart';

class StudentAssignmentDetailsScreen extends StatefulWidget {
  final String assignmentId;

  const StudentAssignmentDetailsScreen({
    super.key,
    required this.assignmentId,
  });

  @override
  State<StudentAssignmentDetailsScreen> createState() =>
      _StudentAssignmentDetailsScreenState();
}

class _StudentAssignmentDetailsScreenState
    extends State<StudentAssignmentDetailsScreen> {
  final FirestoreService _service = FirestoreService();
  final PdfStorageService _pdfStorage = PdfStorageService();
  final TextEditingController _submissionController = TextEditingController();

  bool _loading = false;
  PlatformFile? _selectedPdf;

  @override
  void dispose() {
    _submissionController.dispose();
    super.dispose();
  }

  String _date(dynamic value) {
    if (value is! Timestamp) return 'No due date';
    final d = value.toDate();
    return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year} '
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  Future<void> _pickPdf() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['pdf'],
      withData: false,
    );

    if (result == null || result.files.isEmpty) return;

    final file = result.files.single;
    if (file.path == null) {
      _message('Unable to access the selected PDF.', true);
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      _message('PDF must be 10 MB or smaller.', true);
      return;
    }

    setState(() => _selectedPdf = file);
  }

  Future<void> _openPdf(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) return;

    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened && mounted) _message('Could not open the PDF.', true);
  }

  Future<void> _submit(Map<String, dynamic> assignment) async {
    if (_loading) return;

    final text = _submissionController.text.trim();
    if (text.isEmpty && _selectedPdf == null) {
      _message('Write a submission or attach a PDF.', true);
      return;
    }

    setState(() => _loading = true);

    String? uploadedPath;
    try {
      Map<String, String>? upload;

      // Upload the PDF first. Firestore is only updated after Storage succeeds,
      // so a failed Storage upload cannot leave a misleading submission record.
      if (_selectedPdf != null) {
        upload = await _pdfStorage.uploadSubmissionPdf(
          assignmentId: widget.assignmentId,
          filePath: _selectedPdf!.path!,
          fileName: _selectedPdf!.name,
        );
        uploadedPath = upload['path'];
      }

      final existing = await _service.getStudentSubmission(widget.assignmentId);
      final oldPath = existing.docs.isNotEmpty
          ? (existing.docs.first.data() as Map<String, dynamic>)['pdfPath']?.toString()
          : null;

      final submissionId = await _service.submitAssignment(
        assignmentId: widget.assignmentId,
        assignmentTitle: assignment['title']?.toString() ?? 'Assignment',
        courseId: assignment['courseId']?.toString() ?? '',
        courseName: assignment['courseName']?.toString() ?? 'Course',
        submissionText: text,
        pdfUrl: upload?['url'],
        pdfPath: upload?['path'],
        pdfFileName: upload?['name'],
      );

      // If a new PDF replaced an older one, remove the old Storage object.
      if (upload != null && oldPath != null && oldPath.isNotEmpty && oldPath != uploadedPath) {
        await _pdfStorage.deleteFile(oldPath);
      }

      if (!mounted) return;
      _submissionController.clear();
      setState(() => _selectedPdf = null);
      _message('Assignment submitted successfully.');
    } catch (e) {
      if (mounted) {
        _message(e.toString().replaceFirst('Exception: ', ''), true);
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _message(String text, [bool error = false]) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(text),
          backgroundColor: error ? Colors.red : Colors.green,
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Assignment Details'),
        foregroundColor: Colors.white,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF2563EB), Color(0xFF7C3AED)],
            ),
          ),
        ),
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: _service.getAssignment(widget.assignmentId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError || !snapshot.hasData || !snapshot.data!.exists) {
            return Center(
              child: Text(
                'Unable to load this assignment.',
                style: TextStyle(color: colors.error),
              ),
            );
          }

          final data = snapshot.data!.data() as Map<String, dynamic>;
          final title = data['title']?.toString() ?? 'Assignment';
          final course = data['courseName']?.toString() ?? 'Course';
          final description = data['description']?.toString() ?? '';
          final marks = data['totalMarks'] is num
              ? (data['totalMarks'] as num).toInt()
              : 100;
          final attachmentUrl = data['attachmentUrl']?.toString();
          final attachmentName =
              data['attachmentName']?.toString() ?? 'Assignment PDF';

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(
                course,
                style: TextStyle(
                  color: colors.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 14),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Due: ${_date(data['dueDate'])}'),
                      const SizedBox(height: 6),
                      Text('Total marks: $marks'),
                      const SizedBox(height: 16),
                      const Text(
                        'Instructions',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        description.isEmpty
                            ? 'No additional instructions.'
                            : description,
                      ),
                      if (attachmentUrl != null &&
                          attachmentUrl.trim().isNotEmpty) ...[
                        const SizedBox(height: 16),
                        OutlinedButton.icon(
                          onPressed: () => _openPdf(attachmentUrl),
                          icon: const Icon(Icons.picture_as_pdf),
                          label: Text(attachmentName),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Your Submission',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _submissionController,
                maxLines: 6,
                decoration: const InputDecoration(
                  labelText: 'Submission message',
                  hintText: 'Add a short note about your submission...',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.picture_as_pdf),
                  title: Text(
                    _selectedPdf?.name ?? 'No PDF selected',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: _selectedPdf == null
                      ? const Text('Attach your completed assignment as PDF.')
                      : Text(
                          '${(_selectedPdf!.size / 1024).toStringAsFixed(1)} KB',
                        ),
                  trailing: IconButton(
                    onPressed: _loading ? null : _pickPdf,
                    icon: const Icon(Icons.attach_file),
                    tooltip: 'Choose PDF',
                  ),
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                height: 52,
                child: FilledButton.icon(
                  onPressed: _loading ? null : () => _submit(data),
                  icon: _loading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.send),
                  label: Text(
                    _loading ? 'Uploading & submitting...' : 'Submit Assignment',
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
