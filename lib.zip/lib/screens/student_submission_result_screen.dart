import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../services/firestore_service.dart';

class StudentSubmissionResultScreen extends StatelessWidget {
  final String submissionId;

  const StudentSubmissionResultScreen({
    super.key,
    required this.submissionId,
  });

  String _date(dynamic value) {
    if (value is! Timestamp) return 'Unknown';
    final d = value.toDate();
    return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    final service = FirestoreService();
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Assignment Result')),
      body: FutureBuilder<DocumentSnapshot>(
        future: service.getSubmission(submissionId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Unable to load result.\n${snapshot.error}', textAlign: TextAlign.center));
          }
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: Text('Submission not found.'));
          }

          final d = snapshot.data!.data() as Map<String, dynamic>;
          final title = d['assignmentTitle']?.toString() ?? 'Assignment';
          final course = d['courseName']?.toString() ?? 'Course';
          final grade = d['grade'];
          final total = d['totalMarks'] is num ? (d['totalMarks'] as num).toInt() : 100;
          final feedback = d['feedback']?.toString().trim() ?? '';
          final status = d['status']?.toString() ?? 'submitted';
          final answer = d['submissionText']?.toString() ?? '';

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              Text(course, style: TextStyle(color: cs.primary, fontWeight: FontWeight.w600)),
              const SizedBox(height: 18),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      Icon(
                        grade == null ? Icons.hourglass_top : Icons.emoji_events_outlined,
                        size: 58,
                        color: grade == null ? Colors.orange : Colors.green,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        grade == null ? 'Awaiting Grading' : '$grade / $total',
                        style: const TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 5),
                      Text('Status: ${status.toUpperCase()}'),
                      const SizedBox(height: 5),
                      Text('Submitted: ${_date(d['submittedAt'])}'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const Text('Your Submission', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(answer.isEmpty ? 'No written submission.' : answer, style: const TextStyle(height: 1.5)),
                ),
              ),
              if (grade != null) ...[
                const SizedBox(height: 20),
                const Text('Lecturer Feedback', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Card(
                  color: cs.primary.withValues(alpha: 0.06),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      feedback.isEmpty ? 'No feedback was provided.' : feedback,
                      style: const TextStyle(height: 1.5),
                    ),
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}
