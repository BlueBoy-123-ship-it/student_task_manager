import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

class NotificationService {
  NotificationService._();

  static final NotificationService instance =
      NotificationService._();

  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  // =========================================================
  // INITIALIZE NOTIFICATIONS
  // =========================================================

  Future<void> initialize() async {
    tz.initializeTimeZones();

    const androidSettings = AndroidInitializationSettings(
      '@mipmap/ic_launcher',
    );

    const settings = InitializationSettings(
      android: androidSettings,
    );

    await _notifications.initialize(
      settings: settings,
    );
  }

  // =========================================================
  // REQUEST NOTIFICATION PERMISSION
  // =========================================================

  Future<void> requestPermission() async {
    final androidPlugin =
        _notifications.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    await androidPlugin?.requestNotificationsPermission();
  }

  // =========================================================
  // SCHEDULE TASK REMINDER
  // =========================================================

  Future<void> scheduleTaskReminder({
    required int notificationId,
    required String taskTitle,
    required DateTime reminderDateTime,
  }) async {
    final scheduledDate = tz.TZDateTime.from(
      reminderDateTime,
      tz.local,
    );

    // Don't schedule notifications in the past.
    if (scheduledDate.isBefore(
      tz.TZDateTime.now(tz.local),
    )) {
      return;
    }

    const androidDetails = AndroidNotificationDetails(
      'ergobug_task_reminders',
      'Task Reminders',
      channelDescription: 'Reminders for Ergobug tasks',
      importance: Importance.high,
      priority: Priority.high,
    );

    const details = NotificationDetails(
      android: androidDetails,
    );

    await _notifications.zonedSchedule(
      id: notificationId,
      title: 'Task Reminder 🔔',
      body: '$taskTitle is due soon.',
      scheduledDate: scheduledDate,
      notificationDetails: details,
      androidScheduleMode:
    AndroidScheduleMode.inexactAllowWhileIdle,
    );

    print(
      'Notification scheduled for: $scheduledDate',
    );
  }

  // =========================================================
  // TEST NOTIFICATION
  // =========================================================

  Future<void> testNotification() async {
    const androidDetails = AndroidNotificationDetails(
      'ergobug_test_notifications',
      'Test Notifications',
      channelDescription: 'Test notifications for Ergobug',
      importance: Importance.high,
      priority: Priority.high,
    );

    const details = NotificationDetails(
      android: androidDetails,
    );

    final scheduledDate = tz.TZDateTime.now(
      tz.local,
    ).add(
      const Duration(minutes: 1),
    );

    await _notifications.zonedSchedule(
      id: 999999,
      title: 'Ergobug Test 🔔',
      body: 'If you can see this, notifications are working!',
      scheduledDate: scheduledDate,
      notificationDetails: details,
      androidScheduleMode:
          AndroidScheduleMode.inexactAllowWhileIdle,
    );

    print(
      'Test notification scheduled for: $scheduledDate',
    );
  }

  // =========================================================
  // CANCEL TASK REMINDER
  // =========================================================

  Future<void> cancelTaskReminder(
    int notificationId,
  ) async {
    await _notifications.cancel(
      id: notificationId,
    );
  }
}